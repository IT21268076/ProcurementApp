/* eslint-disable prettier/prettier */
// Common
export const white = '#FFFFFF'; 
export const darkWhite = '#f9f9f9';
export const black = '#000000';
export const textInput = '#003f5c';
export const purple = '#61206C'; 
export const darkPurple = '#340040';
export const yellow = '#FFC400'; 


export const inputLabel = '#808080'; 
