/* eslint-disable prettier/prettier */
import * as Colors from './colors';
import * as Strings from './strings';

export {Strings, Colors};
